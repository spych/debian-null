# Change Log

All notable changes to the Remote Repositories extension will be documented in the [VS Code release notes](https://code.visualstudio.com/updates/).
