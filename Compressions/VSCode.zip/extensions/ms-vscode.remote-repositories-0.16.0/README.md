# Remote Repositories

The **Remote Repositories extension** integrates with the GitHub Repositories and Azure Repos extensions, allowing you to quickly browse, search, edit, and commit to remote git repositories directly from within Visual Studio Code.

This extension was previously part of the GitHub Repositories extension.
