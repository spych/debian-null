# README

An extension to preview HTML files while editing them in VSCode

The extension can be activated in two ways

* Toggle Preview - `ctrl+shift+v` or `cmd+shift+v`
* Open Preview to the Side - `ctrl+k v` or `cmd+k v`
