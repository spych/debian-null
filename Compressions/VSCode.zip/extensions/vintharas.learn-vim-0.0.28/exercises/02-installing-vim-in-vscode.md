# Installing Vim in VSCode

If you haven't installed VSCodeVim now is the time to do it.

- Open command palette with `CMD-SHIFT-P` on Mac `CTRL-SHIFT-P` on Windows/Linux.
- Type `Extension`
- Select `Extensions: Install Extension`
- Type `vim`
- Install the first extension that pops up (vscodevim).

When you've done that come back to this editor. Your cursor should no longer be a | but a rectangle.

:O

Now let's take it for a quick ride. Jump to the next chapter.
