# Vim's Secret Language

This is a chapter for reflecting, consolidating your knowledge and appreciating how far you've come.

Write down all the operators, motions and commands that you've learned thus far. Don't take a look at the cheatsheet or any other reference. Just write down the ones that you can remember from the top of your head.

> Remember that you can use mnemonics to recall the commands based on what they do. Vim is really great at that.

```
Command - what does it do?
=============================
j - move cursor down

```

When you're done write down the number of commands that you've learned and take a moment to celebrate how much you've learned! Wihoo! If you feel like it, share it with me on [twitter](https://twitter.com/Vintharas) and I'll give you a massive kudos. :D

Now dance!!

```
♪┏(・o･)┛♪┗ ( ･o･) ┓♪
```
