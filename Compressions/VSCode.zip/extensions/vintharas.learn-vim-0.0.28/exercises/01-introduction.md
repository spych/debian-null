# Introduction!

Here you learn about Vim and you pumped up for what's to come:

> Vim is for programmers who want to raise their game. In the hands of an expert, Vim shreds text at the speed of thought.
