# Moving Even Faster With vim-sneak and easymotion

Coming soon
